// ── Konton ────────────────────────────────────────────────────────────────
export type AccountType = 'income' | 'expense' | 'asset' | 'liability' | 'equity'
export type AccountCategory =
  | 'revenue' | 'cogs' | 'external' | 'other_opex'
  | 'personnel' | 'financial' | 'current_assets' | 'current_liab' | 'equity'

export interface Account {
  accountNumber: string
  name: string
  type: AccountType
  category: AccountCategory
}

// ── Transaktioner ─────────────────────────────────────────────────────────
export interface Transaction {
  id?: string
  org_id?: string
  date: string
  account: string
  amount: number
  ver_number: string
  description: string
  source?: 'sie' | 'fortnox'
}

// ── SIE-data ──────────────────────────────────────────────────────────────
export interface Verification {
  number: string
  date: string
  description: string
  transactions: Transaction[]
}

export interface SIEData {
  companyName: string
  orgNumber: string
  fiscalYearStart: string
  fiscalYearEnd: string
  accounts: Map<string, Account>
  verifications: Verification[]
  openingBalances: Map<string, number>
  closingBalances: Map<string, number>
}

// ── Sammanfattning ────────────────────────────────────────────────────────
export interface MonthlyData {
  month: string
  revenue: number
  expenses: number
  profit: number
  personnel: number
}

export interface FinancialSummary {
  totalRevenue: number
  totalExpenses: number
  profit: number
  grossMargin: number
  operatingMargin: number
  liquidity: number
  solvency: number
  personnelRatio: number
}

// ── Prognos ───────────────────────────────────────────────────────────────
export interface ForecastMonth {
  month: string
  projectedRevenue: number
  projectedExpenses: number
  netCashFlow: number
  accumulatedLiquidity: number
  riskLevel: 'low' | 'medium' | 'high'
}

// ── Fortnox webhook ───────────────────────────────────────────────────────
export interface FortnoxWebhookPayload {
  eventName: 'voucher.created' | 'voucher.updated' | 'voucher.deleted'
  entityId: string
  clientId: string
  timestamp: string
}

export interface FortnoxVoucher {
  VoucherNumber: string
  VoucherSeries: string
  TransactionDate: string
  Description: string
  VoucherRows: {
    Account: number
    Debit: number
    Credit: number
    Description: string
  }[]
}
