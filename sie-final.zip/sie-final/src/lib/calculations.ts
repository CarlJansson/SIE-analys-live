import type { SIEData, MonthlyData, FinancialSummary } from './types'

export function calculateMonthly(data: SIEData): MonthlyData[] {
  const map = new Map<string, MonthlyData>()

  for (const ver of data.verifications) {
    const ym = ver.date.substring(0, 6) // YYYYMM
    if (!map.has(ym)) {
      map.set(ym, {
        month:     `${ym.substring(0,4)}-${ym.substring(4,6)}`,
        revenue:   0,
        expenses:  0,
        profit:    0,
        personnel: 0,
      })
    }
    const m = map.get(ym)!
    for (const t of ver.transactions) {
      const acc = data.accounts.get(t.account)
      if (!acc) continue
      if (acc.type === 'income')   m.revenue  += Math.abs(t.amount)
      if (acc.type === 'expense')  m.expenses += Math.abs(t.amount)
      if (acc.category === 'personnel') m.personnel += Math.abs(t.amount)
    }
    m.profit = m.revenue - m.expenses
  }

  return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month))
}

export function calculateSummary(
  data: SIEData,
  monthly: MonthlyData[]
): FinancialSummary {
  const totalRevenue  = monthly.reduce((s, m) => s + m.revenue, 0)
  const totalExpenses = monthly.reduce((s, m) => s + m.expenses, 0)
  const profit        = totalRevenue - totalExpenses
  const personnel     = monthly.reduce((s, m) => s + m.personnel, 0)

  let currentAssets = 0, currentLiab = 0, equity = 0, totalAssets = 0

  for (const [num, bal] of data.closingBalances) {
    const acc = data.accounts.get(num)
    if (!acc) continue
    if (acc.category === 'current_assets') currentAssets += bal
    if (acc.category === 'current_liab')   currentLiab   += Math.abs(bal)
    if (acc.category === 'equity')         equity        += Math.abs(bal)
    if (acc.type === 'asset')              totalAssets   += bal
  }

  return {
    totalRevenue,
    totalExpenses,
    profit,
    grossMargin:       totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0,
    operatingMargin:   totalRevenue > 0 ? (profit / totalRevenue) * 100 : 0,
    liquidity:         currentLiab > 0  ? currentAssets / currentLiab  : 0,
    solvency:          totalAssets > 0  ? (equity / totalAssets) * 100  : 0,
    personnelRatio:    totalRevenue > 0 ? (personnel / totalRevenue) * 100 : 0,
  }
}
