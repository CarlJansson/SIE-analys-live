import type { SIEData, Account, Verification, Transaction } from './types'

export function parseSIE4(content: string): SIEData {
  // SIE-filer kan vara CP437 eller Latin-1 — normalisera radbrytningar
  const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean)

  const data: SIEData = {
    companyName: '',
    orgNumber: '',
    fiscalYearStart: '',
    fiscalYearEnd: '',
    accounts: new Map(),
    verifications: [],
    openingBalances: new Map(),
    closingBalances: new Map(),
  }

  let currentVer: Verification | null = null

  for (const line of lines) {
    const parts = tokenizeLine(line)
    const tag = parts[0]

    switch (tag) {
      case '#FNAMN':
        data.companyName = stripQuotes(parts[1] ?? '')
        break

      case '#ORGNR':
        data.orgNumber = parts[1] ?? ''
        break

      case '#RAR':
        if (parts[1] === '0') {
          data.fiscalYearStart = parts[2] ?? ''
          data.fiscalYearEnd   = parts[3] ?? ''
        }
        break

      case '#KONTO': {
        const num  = parts[1]
        const name = stripQuotes(parts[2] ?? '')
        if (num) {
          data.accounts.set(num, {
            accountNumber: num,
            name,
            type:     classifyType(num),
            category: classifyCategory(num),
          })
        }
        break
      }

      case '#IB':
        if (parts[1] === '0' && parts[2]) {
          data.openingBalances.set(parts[2], parseFloat(parts[3] ?? '0'))
        }
        break

      case '#UB':
        if (parts[1] === '0' && parts[2]) {
          data.closingBalances.set(parts[2], parseFloat(parts[3] ?? '0'))
        }
        break

      case '#VER':
        currentVer = {
          number:      parts[2] ?? '',
          date:        parts[3] ?? '',
          description: stripQuotes(parts[4] ?? ''),
          transactions: [],
        }
        data.verifications.push(currentVer)
        break

      case '#TRANS':
        if (currentVer) {
          currentVer.transactions.push({
            account:    parts[1] ?? '',
            amount:     parseFloat(parts[3] ?? '0'),
            date:       parts[4] ?? currentVer.date,
            ver_number: currentVer.number,
            description: stripQuotes(parts[5] ?? currentVer.description),
          })
        }
        break

      case '}':
        currentVer = null
        break
    }
  }

  return data
}

function tokenizeLine(line: string): string[] {
  const tokens: string[] = []
  let current = ''
  let inQuote = false
  for (const ch of line) {
    if (ch === '"') { inQuote = !inQuote; current += ch }
    else if (ch === ' ' && !inQuote) { if (current) tokens.push(current); current = '' }
    else current += ch
  }
  if (current) tokens.push(current)
  return tokens
}

function stripQuotes(s: string) { return s.replace(/^"|"$/g, '') }

function classifyType(num: string): Account['type'] {
  const c = parseInt(num[0])
  if (c === 3) return 'income'
  if (c >= 4 && c <= 8) return 'expense'
  if (c === 1) return 'asset'
  if (c === 2) return 'liability'
  return 'asset'
}

function classifyCategory(num: string): Account['category'] {
  const n = parseInt(num)
  if (n >= 3000 && n < 4000) return 'revenue'
  if (n >= 4000 && n < 5000) return 'cogs'
  if (n >= 5000 && n < 6000) return 'external'
  if (n >= 6000 && n < 7000) return 'other_opex'
  if (n >= 7000 && n < 8000) return 'personnel'
  if (n >= 8000 && n < 9000) return 'financial'
  if (n >= 1500 && n < 2000) return 'current_assets'
  if (n >= 2400 && n < 2900) return 'current_liab'
  if (n >= 2000 && n < 2400) return 'equity'
  return 'current_assets'
}
