import type { MonthlyData, ForecastMonth } from './types'

export function generateForecast(historical: MonthlyData[], months = 3): ForecastMonth[] {
  if (historical.length < 3) return []

  const recent   = historical.slice(-6)
  const avgRev   = recent.reduce((s, m) => s + m.revenue, 0)  / recent.length
  const avgCost  = recent.reduce((s, m) => s + m.expenses, 0) / recent.length
  const seasons  = seasonFactors(historical)
  const last     = historical[historical.length - 1]
  let accLiq     = last.profit

  return Array.from({ length: months }, (_, i) => {
    const targetMonth = addMonths(last.month, i + 1)
    const mNum        = parseInt(targetMonth.split('-')[1])
    const projRev     = avgRev  * (seasons[mNum] ?? 1)
    const projCost    = avgCost * 1.02
    const net         = projRev - projCost
    accLiq           += net

    return {
      month:                 targetMonth,
      projectedRevenue:      Math.round(projRev),
      projectedExpenses:     Math.round(projCost),
      netCashFlow:           Math.round(net),
      accumulatedLiquidity:  Math.round(accLiq),
      riskLevel:             net < 0 || accLiq < 50_000 ? 'high' : net < 50_000 ? 'medium' : 'low',
    }
  })
}

function seasonFactors(data: MonthlyData[]) {
  const byMonth: Record<number, number[]> = {}
  for (const d of data) {
    const m = parseInt(d.month.split('-')[1])
    ;(byMonth[m] ??= []).push(d.revenue)
  }
  const overall = data.reduce((s, d) => s + d.revenue, 0) / data.length
  const f: Record<number, number> = {}
  for (const [m, vals] of Object.entries(byMonth)) {
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length
    f[parseInt(m)] = overall > 0 ? avg / overall : 1
  }
  return f
}

function addMonths(ym: string, n: number) {
  const [y, m] = ym.split('-').map(Number)
  const d = new Date(y, m - 1 + n, 1)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}
