'use client'
import { useCallback, useState } from 'react'

interface MonthlyData { month: string; revenue: number; expenses: number; profit: number }
interface Summary { totalRevenue: number; totalExpenses: number; profit: number; operatingMargin: number }

function parseSIE(content: string) {
  const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean)
  let companyName = 'Ditt företag'
  const monthly: Record<string, MonthlyData> = {}
  let currentVerDate = ''

  for (const line of lines) {
    const parts = line.match(/(".*?"|\S+)/g) || []
    const tag = parts[0]
    if (tag === '#FNAMN') companyName = parts[1]?.replace(/"/g,'') || companyName
    if (tag === '#VER') currentVerDate = parts[3] || ''
    if (tag === '#TRANS' && currentVerDate) {
      const ym = currentVerDate.substring(0,6)
      const acc = parseInt(parts[1] || '0')
      const amt = parseFloat(parts[3] || '0')
      if (!monthly[ym]) monthly[ym] = { month: `${ym.substring(0,4)}-${ym.substring(4,6)}`, revenue:0, expenses:0, profit:0 }
      if (acc >= 3000 && acc < 4000) monthly[ym].revenue += Math.abs(amt)
      if (acc >= 4000 && acc < 9000) monthly[ym].expenses += Math.abs(amt)
    }
  }
  const months = Object.values(monthly).sort((a,b) => a.month.localeCompare(b.month))
  months.forEach(m => m.profit = m.revenue - m.expenses)
  const totalRevenue = months.reduce((s,m) => s+m.revenue, 0)
  const totalExpenses = months.reduce((s,m) => s+m.expenses, 0)
  const profit = totalRevenue - totalExpenses
  return { companyName, monthly: months, summary: { totalRevenue, totalExpenses, profit, operatingMargin: totalRevenue > 0 ? (profit/totalRevenue)*100 : 0 } }
}

const fmt = (n: number) => new Intl.NumberFormat('sv-SE', { maximumFractionDigits:0 }).format(n) + ' kr'
const s = { background:'#141416', border:'1px solid #2a2a2f', borderRadius:12 } as const

export default function Dashboard() {
  const [data, setData] = useState<{ companyName: string; monthly: MonthlyData[]; summary: Summary } | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setLoading(true)
    setError('')
    const reader = new FileReader()
    reader.onload = ev => {
      try {
        const result = parseSIE(ev.target?.result as string)
        setData(result)
      } catch {
        setError('Kunde inte läsa filen. Kontrollera att det är en SIE4-fil.')
      }
      setLoading(false)
    }
    reader.readAsText(file, 'latin1')
  }, [])

  const maxRev = data ? Math.max(...data.monthly.map(m => m.revenue), 1) : 1

  return (
    <div style={{ display:'flex', minHeight:'100vh' }}>
      <aside style={{ width:220, ...s, borderRadius:0, borderTop:'none', borderBottom:'none', borderLeft:'none', display:'flex', flexDirection:'column' }}>
        <div style={{ padding:'18px', borderBottom:'1px solid #2a2a2f', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:30, height:30, background:'#5b8def', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, color:'#fff' }}>Ā</div>
          <div style={{ fontWeight:600, fontSize:14 }}>SIE Analys</div>
        </div>
        <nav style={{ padding:'10px 8px', flex:1 }}>
          <div style={{ padding:'8px 10px', borderRadius:7, fontSize:13, color:'#5b8def', background:'rgba(91,141,239,.1)' }}>Dashboard</div>
        </nav>
        <div style={{ padding:12, borderTop:'1px solid #2a2a2f' }}>
          <label style={{ display:'block', width:'100%', padding:9, background:'#5b8def', borderRadius:7, color:'#fff', fontSize:13, fontWeight:500, cursor:'pointer', textAlign:'center' }}>
            ↑ Ladda upp SIE
            <input type="file" accept=".si,.se,.SIE,.sie" onChange={handleFile} style={{ display:'none' }} />
          </label>
        </div>
      </aside>

      <main style={{ flex:1, padding:24, overflowY:'auto' }}>
        {!data && !loading && (
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'70vh' }}>
            <label style={{ border:'2px dashed #35353c', borderRadius:16, padding:'60px 80px', display:'flex', flexDirection:'column', alignItems:'center', gap:14, cursor:'pointer', textAlign:'center' }}>
              <div style={{ fontSize:44, opacity:.3 }}>⬆</div>
              <div style={{ fontSize:17, fontWeight:500 }}>Ladda upp din SIE4-fil</div>
              <div style={{ fontSize:13, color:'#9898a6', maxWidth:300, lineHeight:1.7 }}>Exportera från Fortnox, Visma eller Bokio och ladda upp här. Data analyseras lokalt i din webbläsare.</div>
              <div style={{ fontSize:11, color:'#5c5c6b', fontFamily:'monospace' }}>.SI · .SE · SIE4-format</div>
              {error && <div style={{ color:'#f06464', fontSize:13 }}>{error}</div>}
              <input type="file" accept=".si,.se,.SIE,.sie" onChange={handleFile} style={{ display:'none' }} />
            </label>
          </div>
        )}

        {loading && (
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', minHeight:'60vh', color:'#9898a6' }}>
            Analyserar filen...
          </div>
        )}

        {data && !loading && (
          <>
            <div style={{ marginBottom:20 }}>
              <h1 style={{ fontSize:21, fontWeight:600, letterSpacing:'-.4px', margin:0 }}>{data.companyName}</h1>
              <div style={{ fontSize:12, color:'#9898a6', marginTop:3 }}>SIE4-analys · {data.monthly.length} månader</div>
            </div>

            <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10, marginBottom:16 }}>
              {[
                { label:'Omsättning',      value:fmt(data.summary.totalRevenue),               accent:'#5b8def' },
                { label:'Rörelseresultat', value:fmt(data.summary.profit),                     accent: data.summary.profit >= 0 ? '#3ecf8e' : '#f06464' },
                { label:'Rörelsemarginal', value:`${data.summary.operatingMargin.toFixed(1)}%`, accent:'#a78bfa' },
                { label:'Kostnader',       value:fmt(data.summary.totalExpenses),               accent:'#f06464' },
                { label:'Antal månader',   value:String(data.monthly.length),                   accent:'#f5a623' },
                { label:'Snitt per månad', value:fmt(data.summary.totalRevenue / Math.max(data.monthly.length,1)), accent:'#2dd4bf' },
              ].map(k => (
                <div key={k.label} style={{ ...s, padding:'14px 16px', position:'relative', overflow:'hidden' }}>
                  <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:k.accent }} />
                  <div style={{ fontSize:11, color:'#9898a6', textTransform:'uppercase', letterSpacing:'.6px', marginBottom:6 }}>{k.label}</div>
                  <div style={{ fontSize:20, fontWeight:600 }}>{k.value}</div>
                </div>
              ))}
            </div>

            <div style={{ ...s, padding:18, marginBottom:14 }}>
              <div style={{ fontSize:13, fontWeight:500, marginBottom:14 }}>Omsättning per månad</div>
              <div style={{ display:'flex', alignItems:'flex-end', gap:6, height:160 }}>
                {data.monthly.map(m => (
                  <div key={m.month} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
                    <div style={{ width:'100%', background: m.profit >= 0 ? '#5b8def' : '#f06464', borderRadius:'3px 3px 0 0', height:`${Math.round((m.revenue/maxRev)*140)}px`, minHeight:2, opacity:.8 }} title={`${m.month}: ${fmt(m.revenue)}`} />
                    <div style={{ fontSize:9, color:'#5c5c6b', fontFamily:'monospace', transform:'rotate(-45deg)', whiteSpace:'nowrap' }}>{m.month.substring(5)}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ ...s, overflow:'hidden' }}>
              <div style={{ padding:'14px 18px', borderBottom:'1px solid #2a2a2f', fontSize:13, fontWeight:500 }}>Månadsöversikt</div>
              <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12.5 }}>
                <thead>
                  <tr>
                    {['Månad','Intäkter','Kostnader','Resultat'].map(h => (
                      <th key={h} style={{ padding:'8px 18px', textAlign:'left', fontSize:11, color:'#5c5c6b', textTransform:'uppercase', letterSpacing:'.5px', borderBottom:'1px solid #2a2a2f' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.monthly.map(m => (
                    <tr key={m.month} style={{ borderBottom:'1px solid rgba(255,255,255,.04)' }}>
                      <td style={{ padding:'10px 18px', color:'#9898a6', fontFamily:'monospace' }}>{m.month}</td>
                      <td style={{ padding:'10px 18px', color:'#3ecf8e', fontFamily:'monospace' }}>{fmt(m.revenue)}</td>
                      <td style={{ padding:'10px 18px', color:'#f06464', fontFamily:'monospace' }}>{fmt(m.expenses)}</td>
                      <td style={{ padding:'10px 18px', color: m.profit >= 0 ? '#3ecf8e' : '#f06464', fontFamily:'monospace' }}>{fmt(m.profit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
