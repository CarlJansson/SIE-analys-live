'use client'
import { create } from 'zustand'
import type { SIEData, MonthlyData, FinancialSummary, ForecastMonth } from '@/lib/types'
import { parseSIE4 }           from '@/lib/sie-parser'
import { calculateMonthly, calculateSummary } from '@/lib/calculations'
import { generateForecast }    from '@/lib/forecast'

interface Store {
  sieData:    SIEData | null
  monthly:    MonthlyData[]
  summary:    FinancialSummary | null
  forecast:   ForecastMonth[]
  fileName:   string
  isLoading:  boolean
  error:      string | null
  loadFile:   (content: string, name: string) => void
  reset:      () => void
}

export const useFinanceStore = create<Store>((set) => ({
  sieData:   null,
  monthly:   [],
  summary:   null,
  forecast:  [],
  fileName:  '',
  isLoading: false,
  error:     null,

  loadFile: (content, name) => {
    set({ isLoading: true, error: null })
    try {
      const sieData  = parseSIE4(content)
      const monthly  = calculateMonthly(sieData)
      const summary  = calculateSummary(sieData, monthly)
      const forecast = generateForecast(monthly)
      set({ sieData, monthly, summary, forecast, fileName: name, isLoading: false })
    } catch (e) {
      set({ error: 'Kunde inte läsa SIE-filen. Kontrollera att det är en giltig SIE4-fil.', isLoading: false })
    }
  },

  reset: () => set({ sieData: null, monthly: [], summary: null, forecast: [], fileName: '' }),
}))
